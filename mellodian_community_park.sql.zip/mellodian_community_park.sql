-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 14, 2022 at 02:31 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mellodian_community_park`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(100) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `first_name`, `last_name`, `user_name`, `email`, `password`) VALUES
(1, 'Adekunle', 'Idris', 'Adekunle', 'adekunleidris@gmail.com', 'adenkule123'),
(2, 'Catherine', 'Drah', 'catherine', 'catherindrah@gmail.com', 'cath123');

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `book_id` int(100) NOT NULL,
  `book_user_id` int(100) NOT NULL,
  `book_user_name` varchar(100) NOT NULL,
  `book_event_name` varchar(100) NOT NULL,
  `book_event_price` int(100) NOT NULL,
  `book_seats_type` varchar(100) NOT NULL,
  `number_of_seats` int(100) NOT NULL,
  `event_date` varchar(100) DEFAULT NULL,
  `booked_on` varchar(100) NOT NULL,
  `book_total` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`book_id`, `book_user_id`, `book_user_name`, `book_event_name`, `book_event_price`, `book_seats_type`, `number_of_seats`, `event_date`, `booked_on`, `book_total`) VALUES
(1, 1, 'Laura Sowah', ' Surfing ', 34, 'With tables', 1, ' 2022-12-24', '29-Nov-2022', 34),
(2, 1, 'Laura Sowah', ' Sweeny ', 12, 'Without tables', 1, ' 2022-12-19', '29-Nov-2022', 12),
(3, 1, 'Laura Sowah', ' Swimming ', 43, 'With tables', 5, ' 2022-12-10', '29-Nov-2022', 215);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(100) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `dob` date NOT NULL,
  `email` varchar(100) NOT NULL,
  `telephone` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `first_name`, `last_name`, `username`, `password`, `dob`, `email`, `telephone`, `address`, `image`) VALUES
(1, 'Laura', 'Sowah', 'Laura Sowah', 'laura123', '1990-10-29', 'Laurasowah@gmail.com', '7645245780', 'info:35 , EastSurreyGrove    , SE15 6EX', 'img-2.jpg'),
(2, 'Michel', 'Anim', 'Michel Anim', 'michel123', '1992-12-08', 'MichelAnim@gmail.com', '7523187009', 'info:4Broadway , SE10\r\n        ,  9JS', 'user-2.png');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(100) NOT NULL,
  `event_name` varchar(100) NOT NULL,
  `event_price` int(100) NOT NULL,
  `event_date` date DEFAULT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `event_name`, `event_price`, `event_date`, `image`) VALUES
(1, 'Surfing', 34, '2022-12-25', 'house-2.png'),
(2, 'Sweeny', 12, '2022-12-19', 'story-2.png'),
(3, 'Swimming', 43, '2022-12-10', 'story-3.png'),
(5, 'Ferris Wheel', 12, '2022-12-21', 'new-delhi.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`book_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `book_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
